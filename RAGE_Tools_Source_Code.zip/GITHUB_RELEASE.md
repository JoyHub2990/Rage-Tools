## Added
- **World**: **Extensions** — its own tab in the right panel. Select any prop and edit its archetype's extensions: light shafts, ladders, particle effects, audio emitters, spawn points, doors, wind — every extension type the format supports. Changes draw in the viewport as you type; save the .ytyp to keep them.
- **World**: **Shift+click duplicates** — grab the gizmo with Shift held and the selection is copied in place, ready to drag. Works on world props and on props inside MLO interiors; one undo removes the move, the next removes the copy.
- **World**: open a `.ymap` on its own and the `.ytyp` sitting beside it is pulled in automatically, so your interior stands instead of a bare instance box. If an archetype really can't be found, the Inspector now says so in plain words.
- **MLO Creator**: renaming a prop's archetype now swaps its model — type another prop's name and it takes the old one's place, looked up in the archives and your prop folders.
- **CLI**: `--portalprobe` — builds an interior with rooms, a portal and props, exports it, then reads every part back off disk to prove the files are good.

## Fixed
- **Water**: rivers, lakes and shorelines that were missing now render — surfaces were being discarded over unknown depth, water materials overwrote their own depth limit, cut-corner river quads were drawn as full rectangles, and three of the game's ten water shaders (foam, decal) were routed down the wrong path.
- **Grass**: the racetrack — and every `grass_fur` strip — shows its real ground again. A saturated overlay layer was being drawn on top of the lawn and tinting it lime; that layer is not part of the map view and is now skipped.
- **Grass / terrain**: the warm sheen on grounds is gone — sun specular now uses the engine's own tight highlight formula instead of a wide lobe fed by the HDR sun, and terrain layer blending uses the game's own layer weights.
- **World performance at night**: 43 → 103 fps downtown — LOD lights become real lights near you and hand off to the distant glow sprites past 450 m, instead of burning the whole 2048-light budget out to 3 km.
- **Pixelated prop edges**: leaves and fences are antialiased now (alpha-to-coverage under MSAA) — measured free.
- **Smoother flying**: the streaming stalls while moving the camera are cut down — the resident-set sync is paced and budgeted, and heavy mesh decoding moved off the main thread (worst single hitch from one build: 100 ms → 10 ms).
- **Cutscene proxy buildings** (`hei_dt1_02_impexpproxy` and friends) no longer float over downtown — the game only shows them during cutscenes, so they stay hidden.
- **MLO Creator**: adding the shell as an entity silently shifted which props were attached to portals — attachments now move with it, both ways.

## Changed
- **World panel**: grouped into clean sections instead of one long stack; whole UI on ImGui's ProggyClean font with neutral section colours.
