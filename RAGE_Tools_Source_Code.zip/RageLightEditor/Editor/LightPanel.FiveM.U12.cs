using System;
using System.Collections.Generic;
using System.Numerics;
using ImGuiNET;

namespace RageLightEditor.Editor
{
    public partial class LightPanel
    {
        public bool FiveMWindowOpen_U12;
        public bool FiveMListening_U12;
        public bool FiveMConnected_U12;
        public bool FiveMLive_U12;
        public int FiveMFollow_U12;
        public bool FiveMRestartAfterSave_U12 = true;
        public bool FiveMAutoStart_U12 = true;
        public bool FiveMAnyInterface_U12;
        public int FiveMPort_U12 = FiveMBridge.DefaultPort;
        public string FiveMResourcesFolder_U12 = "";
        public string FiveMRestartName_U12 = "";
        public string FiveMInstalledPath_U12 = "";
        public string FiveMStatus_U12 = "off";
        public string FiveMPlayerText_U12 = "";
        public string FiveMPickText_U12 = "";
        public readonly List<string> FiveMLog_U12 = new List<string>();

        public bool RequestFiveMToggle_U12;
        public bool RequestFiveMInstall_U12;
        public bool RequestFiveMBrowse_U12;
        public bool RequestFiveMRestart_U12;
        public bool RequestFiveMTeleport_U12;
        public bool RequestFiveMGoToPlayer_U12;
        public bool RequestFiveMGoToPick_U12;
        public bool RequestFiveMResend_U12;
        public string RequestFiveMReveal_U12;

        public static readonly Vector4 FiveMMenuColour_U12 = new Vector4(1.0f, 0.62f, 0.2f, 1.0f);

        public void FiveMSay_U12(string line)
        {
            FiveMLog_U12.Add(DateTime.Now.ToString("HH:mm:ss") + "  " + line);
            if (FiveMLog_U12.Count > 12) FiveMLog_U12.RemoveAt(0);
        }

        private void DrawBridgeMenu_U12()
        {
            if (ForceOpenHeader != null && ("Bridge".Contains(ForceOpenHeader, StringComparison.OrdinalIgnoreCase) || "FiveM".Contains(ForceOpenHeader, StringComparison.OrdinalIgnoreCase)))
                FiveMWindowOpen_U12 = true;
            ImGui.PushStyleColor(ImGuiCol.Text, FiveMConnected_U12 ? UiTheme.Ok : FiveMMenuColour_U12);
            bool menuOpen = ImGui.BeginMenu("FiveM Live Linking###bridgemenu");
            ImGui.PopStyleColor();
            if (!menuOpen) return;
            bool vis = FiveMWindowOpen_U12;
            if (ImGui.MenuItem(FiveMConnected_U12 ? "FiveM live link  (game connected)" : "FiveM live link", null, ref vis)) FiveMWindowOpen_U12 = vis;
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("Mirror what you edit here in a running FiveM server: lights, camera, time and weather,\nand reload a resource after you save into it.");
            bool gv = GameViewOpen_U13;
            if (ImGui.MenuItem("Game view (bottom left)", null, ref gv)) GameViewOpen_U13 = gv;
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("A small live picture of the FiveM window with debug info.");
            if (ImGui.MenuItem(FiveMDetached_U14 ? "Attach the panel to the main window" : "Detach the panel into its own window"))
            {
                if (FiveMDetached_U14) RequestFiveMAttach_U14 = true;
                else RequestFiveMDetach_U14 = true;
            }
            ImGui.Separator();
            var mlo = MloCreator;
            bool api = mlo != null && mlo.BridgeEnabled;
            if (ImGui.MenuItem(api ? $"Stop the local API  (port {mlo.BridgePort})" : "Start the local API for scripts") && mlo != null) mlo.RequestBridgeToggle = true;
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("A plain JSON socket on 127.0.0.1 that scripts and AI tools can drive.\nNot needed for the game link.");
            ImGui.EndMenu();
        }

        private void DrawFiveMWindow_U12(float displayWidth, float displayHeight)
        {
            if (!FiveMWindowOpen_U12 || FiveMDetached_U14) return;
            ImGui.SetNextWindowSize(new Vector2(760, Math.Min(900, Math.Max(displayHeight - TopBarHeight - 40, 500))), ImGuiCond.FirstUseEver);
            ImGui.SetNextWindowPos(new Vector2(Math.Max(displayWidth - 790, 20), Math.Max(TopBarHeight + 20, 20)), ImGuiCond.FirstUseEver);
            bool open = FiveMWindowOpen_U12;
            if (!ImGui.Begin("FiveM Live Linking###fivemlink2", ref open))
            {
                FiveMWindowOpen_U12 = open;
                ImGui.End();
                return;
            }
            FiveMWindowOpen_U12 = open;
            DrawFiveMDetachRow_U14();
            DrawFiveMBody_U12();
            ImGui.End();
        }

        private void FiveMToggle_U12(string label, ref bool value, string tip)
        {
            ImGui.Checkbox(label, ref value);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip(tip);
        }

        public void DrawFiveMBody_U12()
        {
            ImGui.TextDisabled("GAME");
            DrawFiveMWarning_U16();
            var dotColour = FiveMConnected_U12 ? UiTheme.Ok : (FiveMListening_U12 ? UiTheme.Warn : UiTheme.Muted);
            ImGui.TextColored(dotColour, FiveMConnected_U12 ? "connected" : (FiveMListening_U12 ? "waiting for the game" : "off"));
            ImGui.SameLine();
            ImGui.TextDisabled(FiveMStatus_U12 ?? "");
            if (!string.IsNullOrEmpty(FiveMPlayerText_U12)) ImGui.TextDisabled(FiveMPlayerText_U12);

            bool on = FiveMListening_U12;
            ImGui.PushStyleColor(ImGuiCol.Button, on ? UiTheme.DangerButton : UiTheme.AccentDim);
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, on ? UiTheme.DangerButtonHi : UiTheme.Accent);
            if (ImGui.Button(on ? "Stop listening" : "Start listening", new Vector2(150, 0))) RequestFiveMToggle_U12 = true;
            ImGui.PopStyleColor(2);
            ImGui.SameLine();
            ImGui.SetNextItemWidth(90);
            if (!on) ImGui.InputInt("port##fivemport", ref FiveMPort_U12, 0, 0);
            else ImGui.TextDisabled($"port {FiveMPort_U12}");
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("The game's resource connects to this port. 27018 is the default;\nchange it here and reinstall the resource if something else has it.");
            ImGui.SameLine();
            FiveMToggle_U12("start with the tool", ref FiveMAutoStart_U12, "Listen as soon as RAGE Tools starts, so the game links up on its own.");
            if (!on) FiveMToggle_U12("game on another PC (listen on every network interface)", ref FiveMAnyInterface_U12,
                                     "Off: only this PC can connect. On: a FiveM client on your LAN can connect too;\nreinstall the resource so it carries this PC's address.");

            ImGui.Spacing();
            ImGui.TextDisabled("LIVE");
            FiveMToggle_U12("Live: the game follows what you edit", ref FiveMLive_U12,
                            "Lights of the open prop are drawn on that prop in the game as you change them,\nand the game clock and weather follow the tool. Off sends nothing.");
            ImGui.TextDisabled("Camera");
            ImGui.SameLine();
            ImGui.RadioButton("off##fmcam", ref FiveMFollow_U12, 0);
            ImGui.SameLine();
            ImGui.RadioButton("game follows the editor##fmcam", ref FiveMFollow_U12, 1);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("The game's camera goes where this viewport looks. The world streams in around it.");
            ImGui.TextDisabled("      ");
            ImGui.SameLine();
            ImGui.RadioButton("editor follows the game##fmcam", ref FiveMFollow_U12, 2);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("Walk around in the game and this viewport follows your camera.");
            FiveMToggle_U12("Restart the resource after a save", ref FiveMRestartAfterSave_U12,
                            "When you save a file that sits inside a server resource, that resource is restarted\nso the game reloads the new file. Needs 'set ragetools_dev 1' in server.cfg.");

            ImGui.SetNextItemWidth(200);
            ImGui.InputText("resource##fmrestartname", ref FiveMRestartName_U12, 128);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("Filled in from the last save. Type any resource name to restart it by hand.");
            ImGui.SameLine();
            ImGui.BeginDisabled(!FiveMConnected_U12 || string.IsNullOrWhiteSpace(FiveMRestartName_U12));
            if (ImGui.Button("Restart it now")) RequestFiveMRestart_U12 = true;
            ImGui.EndDisabled();

            ImGui.BeginDisabled(!FiveMConnected_U12);
            if (ImGui.Button("Player to the camera")) RequestFiveMTeleport_U12 = true;
            if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)) ImGui.SetTooltip("Teleports your ped to where this viewport's camera is.");
            ImGui.SameLine();
            if (ImGui.Button("Camera to the player")) RequestFiveMGoToPlayer_U12 = true;
            if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)) ImGui.SetTooltip("Moves this viewport's camera to your ped in the game (once).");
            ImGui.SameLine();
            if (ImGui.Button("Send the lights again")) RequestFiveMResend_U12 = true;
            ImGui.EndDisabled();
            if (!string.IsNullOrEmpty(FiveMPickText_U12))
            {
                ImGui.TextColored(UiTheme.Accent, FiveMPickText_U12);
                ImGui.SameLine();
                if (ImGui.SmallButton("look at it##fmpick")) RequestFiveMGoToPick_U12 = true;
            }
            ImGui.TextDisabled("In the game, F9 picks the prop you look at and reports it here.");

            ImGui.Spacing();
            ImGui.Separator();
            ImGui.TextDisabled("INSTALL  (once per server)");
            ImGui.SetNextItemWidth(-90);
            ImGui.InputText("##fmfolder", ref FiveMResourcesFolder_U12, 512);
            if (ImGui.IsItemHovered()) ImGui.SetTooltip("Your server's resources folder, the one server.cfg's 'ensure' lines refer to.");
            ImGui.SameLine();
            if (ImGui.Button("Browse...##fmbrowse", new Vector2(80, 0))) RequestFiveMBrowse_U12 = true;
            ImGui.BeginDisabled(string.IsNullOrWhiteSpace(FiveMResourcesFolder_U12));
            if (ImGui.Button("Install / update the resource", new Vector2(-1, 0))) RequestFiveMInstall_U12 = true;
            ImGui.EndDisabled();
            if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled)) ImGui.SetTooltip("Writes the 'rage_tools_bridge' resource into that folder with this port inside it.\nRun it again after changing the port or the network option.");
            if (!string.IsNullOrEmpty(FiveMInstalledPath_U12))
            {
                ImGui.PushStyleColor(ImGuiCol.Text, UiTheme.Muted);
                ImGui.TextWrapped(FiveMInstalledPath_U12);
                ImGui.PopStyleColor();
                ImGui.SameLine();
                if (ImGui.SmallButton("show##fminstalled")) RequestFiveMReveal_U12 = FiveMInstalledPath_U12;
            }
            ImGui.TextWrapped("Then add to server.cfg:");
            ImGui.SameLine();
            if (ImGui.SmallButton("copy##fmcfg")) ImGui.SetClipboardText("ensure rage_tools_bridge\nset ragetools_dev 1\n");
            ImGui.TextColored(UiTheme.Accent, "ensure rage_tools_bridge");
            ImGui.TextColored(UiTheme.Accent, "set ragetools_dev 1");
            ImGui.TextDisabled("(ragetools_dev lets the tool restart resources - development servers only)");

            ImGui.Spacing();
            DrawFiveMExtras_U13();

            ImGui.TextDisabled("LOG");
            ImGui.BeginChild("##fivemlog", new Vector2(0, 120), ImGuiChildFlags.Borders);
            foreach (var l in FiveMLog_U12) ImGui.TextWrapped(l);
            if (FiveMLog_U12.Count == 0) ImGui.TextDisabled("  nothing yet");
            ImGui.EndChild();

            ImGui.SetNextItemOpen(true, ImGuiCond.FirstUseEver);
            if (ImGui.CollapsingHeader("How it works"))
            {
                ImGui.TextWrapped("1. Install the resource into your server, add the two server.cfg lines, start the server and join it.");
                ImGui.TextWrapped("2. The resource connects to this tool over the network (this PC by default). The dot above turns green.");
                ImGui.TextWrapped("3. Turn Live on. Open a prop in Lights: its lights are drawn on the same prop in the game as you edit them " +
                                  "(the game finds the nearest copy of that model; if there is none near you, it places a preview copy in front of you). " +
                                  "Coronas and volumes cannot be drawn by a script, the rest can.");
                ImGui.TextWrapped("4. Save a file that lives in a resource's stream folder and that resource is restarted, so new models, textures " +
                                  "and interiors show up in the game a few seconds later. That is the path for everything the game cannot change live.");
                ImGui.TextDisabled("docs/fivem.md has the message list.");
            }
        }
    }
}
